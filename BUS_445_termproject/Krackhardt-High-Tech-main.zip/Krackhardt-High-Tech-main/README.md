# KRACKHARDT-HIGH-TECH MULTIPLEX NETWORK

###### Last update: 29 Aug 2025

### Reference and Acknowledgments

This README file accompanies the dataset representing the multiplex social network of the managers of a high-tech company.
If you use this dataset in your work either for analysis or for visualization, you should acknowledge/cite the following papers:

	"Cognitive social structures"
	D. Krackhardt
	Social Networks (1987), 9, 104-134


### Description of the dataset

The multiplex social network consists of 3 kinds of relationships (Advice, Friendship and "Reports to") between managers of a high-tech company.

There are 21 nodes in total, labelled with integer ID between 1 and 21, with 312 connections.
The multiplex is directed and unweighted, stored as edges list in the file
    
    Krackhardt-High-Tech_multiplex.edges

with format

    layerID nodeID nodeID weight

(Note: all weights are set to 1)

The IDs of all layers are stored in 

    Krackhardt-High-Tech_layers.txt

The IDs of nodes can be found in the file

    Krackhardt-High-Tech_nodes.txt

The values for the 5 columns (attributes) are

1. node id
2. age (in years)
3. tenure (length of service or tenure in years)
4. level (in the corporate hierarchy; 1 = CEO, 2 = Vice President, 3 = manager)
5. deparment (coded 1,2,3,4 with the CEO in department 0 ie not in a department)


### License

This KRACKHARDT-HIGH-TECH MULTIPLEX DATASET is made available under the Open Database License: <http://opendatacommons.org/licenses/odbl/1.0/>. Any rights in individual contents of the database are licensed under the Database Contents License: <http://opendatacommons.org/licenses/dbcl/1.0/>

You should find a copy of the above licenses accompanying this dataset. If it is not the case, please contact us (see below).

A friendly summary of this license can be found here:

<http://opendatacommons.org/licenses/odbl/summary/>

and is reported in the following.

======================================================
ODC Open Database License (ODbL) Summary

This is a human-readable summary of the ODbL 1.0 license. Please see the disclaimer below.

You are free:

*    To Share: To copy, distribute and use the database.
*    To Create: To produce works from the database.
*    To Adapt: To modify, transform and build upon the database.

As long as you:
    
*	Attribute: You must attribute any public use of the database, or works produced from the database, in the manner specified in the ODbL. For any use or redistribution of the database, or works produced from it, you must make clear to others the license of the database and keep intact any notices on the original database.
    
*	Share-Alike: If you publicly use any adapted version of this database, or works produced from an adapted database, you must also offer that adapted database under the ODbL.
    
*	Keep open: If you redistribute the database, or an adapted version of it, then you may use technological measures that restrict the work (such as DRM) as long as you also redistribute a version without such measures.

======================================================


### Contacts

If you find any error in the dataset or you have questions, please contact

	Manlio De Domenico
	University of Padua 
	Padua (Italy)

email: <manlio.dedomenico@unipd.it>

web: <https://manliodedomenico.com>
